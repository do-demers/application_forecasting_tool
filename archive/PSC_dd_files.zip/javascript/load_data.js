
var dispatch = d3.dispatch("load_viz", "load_tbl", "load_choice", "statechange", "select_change", "viz_change", "tbl_change");

var start_dept = "Public Service Commission of Canada";
var start_grp = "EC";
var start_lvl = "02";
var start_lang = "Various language requirements and/or profiles";
var start_reg = "NCR";
var start_one = "Multiple";
var start_int = "external";

// This will be assigned to rows, once the data is ready.
var data = null;
console.log("1")
d3.csv("raw_data/raw_data.csv")
    .row(function(d) {
        d.applications = +d.applications;
        d.predicted = +d.predicted;
        d.lower = +d.lower;
        d.upper = +d.upper;
        d.days_open = +d.days_open;
        return d;
    })
    .get(function(error, rows) {

        data = rows;// Now you can assign it
        var tbl_data = _.filter(data, function (row, i) {
            return (start_dept === "ANY" ? row.Department_E !== "ANY" : _.contains([row.Department_E], start_dept))
                && _.contains([row.Class_Group], start_grp)
                && _.contains([row.Class_Lvl], start_lvl)
                && _.contains([row.Language], start_lang)
                && _.contains([row.Region_NCR], start_reg)
                && _.contains([row.one_position], start_one)
                && _.contains([row.int_process], start_int);
        });

        var pred_data = _.filter(data, function (row, i) {
            return _.contains([row.Department_E], start_dept)
                && _.contains([row.Class_Group], start_grp)
                && _.contains([row.Class_Lvl], start_lvl)
                && _.contains([row.Language], start_lang)
                && _.contains([row.Region_NCR], start_reg)
                && _.contains([row.one_position], start_one)
                && _.contains([row.int_process], start_int);
        });

        // myDataIsReady()// Now you can draw it

        dispatch.call("load_choice", undefined,data);

        dispatch.call("load_viz", undefined, pred_data);

        dispatch.call("load_tbl", undefined, tbl_data);

        dispatch.call("statechange", undefined, data);

    });


// function myDataIsReady() {
//     console.log(data);// will trace the data that was loaded
// }


// var raw_data = d3.csvParse(temp_raw_data, function (i) {
//     i.applications = +i.applications;
//     return i;
// });
//
// var pred_data = d3.csvParse(temp_pred_data, function (i) {
//
//     i.predicted = +i.predicted;
//     i.lower = +i.lower;
//     i.upper = +i.upper;
//
//     return i;
// });

