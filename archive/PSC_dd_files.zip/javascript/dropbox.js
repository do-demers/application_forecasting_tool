
dispatch.on("load_choice.menu", function (data) {


    var drop_box = function drop_box(variable, prefix, start_var, label) {

        var var_list = _.uniq(_.pluck(data, variable)).sort();

        var var_select = d3.select("#select_div")
            .append("label")
            .attr("id", "sel_lbl")
            .attr("for", "select" + prefix).text(label)
            .append("select")
            .attr("id", "select" + prefix)
            .attr("class", "select_class")
            .on("change", function () {
                dispatch.call("statechange", this, data);
            });

        var_select
            .selectAll("option")
            .data(var_list)
            .enter()
            .append("option")
            .attr("value", function (d) {
                return d;
            }).text(function (d) {
                return d;
            });

            var_select.property("value", start_var);
    };

    drop_box("Class_Group", "_grp", start_grp, "Group:");
    drop_box("Class_Lvl", "_lvl", start_lvl, "Level:");
    drop_box("Department_E", "_dept", start_dept, "Department:");
    drop_box("Language", "_lang", start_lang, "Language:");
    drop_box("Region_NCR", "_reg", start_reg, "Region:");
    drop_box("one_position", "_one", start_one, "Positions:");
    drop_box("int_process", "_int", start_int, "Internal:");

    dispatch.on("statechange.menu", function (filter_data) {

        var current_dept = d3.select("#select_dept").property("value");
        var current_group = d3.select("#select_grp").property("value");
        var current_lvl = d3.select("#select_lvl").property("value");
        var current_lang = d3.select("#select_lang").property("value");
        var current_reg = d3.select("#select_reg").property("value");
        var current_one = d3.select("#select_one").property("value");
        var current_int = d3.select("#select_int").property("value");

        var new_tbl_data = _.filter(data, function (row, i) {
            return (current_dept === "ANY" ? row.Department_E !== "ANY" : _.contains([row.Department_E], current_dept))
                && _.contains([row.Class_Group], current_group)
                && _.contains([row.Class_Lvl], current_lvl)
                && _.contains([row.Language], current_lang)
                && _.contains([row.Region_NCR], current_reg)
                && _.contains([row.one_position], current_one)
                && _.contains([row.int_process], current_int);
        });

        var new_pred_data = _.filter(data, function (row, i) {

            return _.contains([row.Department_E], current_dept)
                && _.contains([row.Class_Group], current_group)
                && _.contains([row.Class_Lvl], current_lvl)
                && _.contains([row.Language], current_lang)
                && _.contains([row.Region_NCR], current_reg)
                && _.contains([row.one_position], current_one)
                && _.contains([row.int_process], current_int);
        });


        dispatch.call("viz_change", this, new_pred_data);
        dispatch.call("tbl_change", this, new_tbl_data);
    });
});
